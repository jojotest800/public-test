const user = true;
const address = true;
const image = true;

module.exports = {
  user,
  address,
  image,
};
