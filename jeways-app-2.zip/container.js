const awilix = require('awilix')


const container = awilix.createContainer()


module.exports = container