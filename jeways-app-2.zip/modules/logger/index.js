const winston = require('winston')


console.log(winston);