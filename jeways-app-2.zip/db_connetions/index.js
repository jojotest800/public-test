const sqlite = require('./sqlite')
const postgres = require('./postgres')


module.exports = {
    sqlite,
    postgres
}